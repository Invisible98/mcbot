import { LoginForm } from '../LoginForm';

export default function LoginFormExample() {
  return <LoginForm onLogin={() => console.log('Login successful')} />;
}