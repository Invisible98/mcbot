import { MobileBotControls } from '../MobileBotControls';

export default function MobileBotControlsExample() {
  return <MobileBotControls onlineCount={3} totalCount={5} />;
}