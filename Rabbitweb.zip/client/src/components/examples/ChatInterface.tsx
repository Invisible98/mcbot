import { ChatInterface } from '../ChatInterface';

export default function ChatInterfaceExample() {
  return <ChatInterface className="h-[600px]" />;
}